<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Egnigyan Education</title>
      <link rel="stylesheet" href="register.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
      <script src="http://code.jquery.com/jquery-3.3.1.js"></script>
      <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600" rel="stylesheet">
</head>
<body>

    <div id ="container">
       
        <div id="topbar">
            <h1>EGNIGYAN</h1>
             <img src="images/logo.jpg" height="50" width="50">
                
        </div>
          </div>
    
      <nav>
        
            <div>
                  <i class="fa fa-bars"></i>
               
            </div>
     
            <ul>
                  <li><a href="Acollege%20portal.html">Admin</a></li>
                  <li><a href="#">Student portal<i class="fa fa-sort-desc"></i></a>
                        <ul>
                              <li><a href="student_login.php">Student Login</a></li>
                              <li><a href="payments.html">Payments</a></li>
                             
                        </ul>
                  </li>
                  <li><a href="#">Faculty portal<i class="fa fa-sort-desc"></i></a>
                        <ul>
                              <li><a href="faculty_login.html">Faculty Login</a></li>
                             
                        </ul>
                  </li>
                
                  <li><a href="parent.html">Parent Login</a></li>
                  <li><a href="5.html">About</a></li>
                  <li><a href="6.html">FAQ</a></li>
            </ul>
           
      </nav>
    
    <script type="text/javascript">
  function validateForm()
  {
    var a=document.forms["reg"]["fname"].value;
    var b=document.forms["reg"]["lname"].value;
    var c=document.forms["reg"]["gender"].value;
    var d=document.forms["reg"]["address"].value;
    var e=document.forms["reg"]["contact"].value;
    var f=document.forms["reg"]["username"].value;
    var g=document.forms["reg"]["password"].value;
    if ((a==null || a=="") && (b==null || b=="") && (c==null || c=="") && (d==null || d=="") && (e==null || e==""))
    {
      alert("All Field must be filled out");
      return false;
    }
    if (a==null || a=="")
    {
      alert("First name must be filled out");
      return false;
    }
    if (b==null || b=="")
    {
      alert("Last name must be filled out");
      return false;
    }
    if (c==null || c=="")
    {
      alert("Gender name must be filled out");
      return false;
    }
    if (d==null || d=="")
    {
      alert("address must be filled out");
      return false;
    }
    if (e==null || e=="")
    {
      alert("contact must be filled out");
      return false;
    }
    if (f==null || f=="")
    {
      alert("username must be filled out");
      return false;
    }
    if (g==null || g=="")
    {
      alert("password must be filled out");
      return false;
    }
  }
</script>
    
  <div class ="container2">
                <div class="imgbox1">
                    <img src="images/student.jpg" width="100" height="100" border="3" style="border-color: darkgoldenrod">
                </div>
            <h3>Courses Registration form</h3>
                <p>You can register any Courses here and can login to portal and access to it.</p>
                    
            </div>

  <div class="containerx">
<form name="reg" action="code_exec.php" onsubmit="return validateForm()" method="post">
  <table width="274" border="0" align="center" cellpadding="2" cellspacing="0">
    <tr>
      <td colspan="2">
        <div align="center">
          <?php 
          
          if (!isset($_GET['remarks']))
          {
            echo 'Courses Register Here';
          }
          if (isset($_GET['remarks']) && $_GET['remarks']=='success')
          {
            echo 'Registration Success';
          }
          ?>  
        </div></td>
      </tr>
     
      <tr>
        <td width="95"><div align="right">First Name:</div></td>
        <td width="171"><input type="text" name="fname" /></td>
      </tr>
      <tr>
        <td><div align="right">Last Name:</div></td>
        <td><input type="text" name="lname" /></td>
      </tr>
      <tr>
          <td>
              
       <span>Courses</span>
              <div id="Courses" class="field cse">
                <select name="state">
                  <option value="cse">Computer Science</option>
                  <option value="es">Electronical Science</option>
                  <option value="ee">EEE</option>
                  <option value="ce">Civil Engineering</option>
                  <option value="ae">Aeronotical</option>
                  <option value="mba">MBA</option>
                  <option value="bba">BBA</option>
                  <option value="bsc">Bsc</option>
                  </select>
              </div>
          </td>
      </tr>
      
      <tr>
        <td><div align="right">Gender:</div></td>
        <td><input type="text" name="gender" /></td>
      </tr>
      <tr>
        <td><div align="right">Address:</div></td>
        <td><input type="text" name="address" /></td>
      </tr>
      <tr>
        <td><div align="right">Contact:</div></td>
        <td><input type="text" name="contact" /></td>
      </tr>
      <tr>
        <td><div align="right">Username:</div></td>
        <td><input type="text" name="username" /></td>
      </tr>
      <tr>
        <td><div align="right">Password:</div></td>
        <td><input type="password" name="password" /></td>
      </tr>
      <tr>
        <td><div align="right">confirm Password:</div></td>
        <td><input type="password" name="password" /></td>
      </tr>
      <tr>
        <td><div align="right"></div></td>
        <td><input name="submit" type="submit" value="Submit" /></td>
      </tr>
     
    </table>
  </form>
     </div>
     <div class ="container6">
                <div class="bottombar">
                    <h5>Our Social media</h5>  
                    <div class="bar">
               <a class="btn" href="https://m.facebook.com/engigyanlivetraining/">
                    <i class="fab fa-facebook-f"></i>
                    </a>
                   <a class="btn" href="https://www.engigyan.com">
                    <i class="fab fa-google"></i>
                    </a>
          <a class="btn" href="https://www.instagram.com/engigyan/?hl=en">
                    <i class="fab fa-instagram"></i>
                    </a>
                </div>
                    <p class="para1">ENGIGYAN - ALL RIGHTS RESERVED.</p>
                    <p class="para2">Powered by Engigyan Technology Private Limited.</p>
         </div>
    </div>
      <script type="text/javascript">

      $("nav div").click(function() {
            $("ul").slideToggle();
            $("ul ul").css("display", "none");
      });

      $("ul li").click(function() {
            $("ul ul").slideUp();
            $(this).find('ul').slideToggle();
      });

      $(window).resize(function() {
            if($(window).width() > 768) {
                  $("ul").removeAttr('style');
            }
      });

      </script>
   

</body>
</html>

   
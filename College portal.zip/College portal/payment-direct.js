function cardnumber(inputtxt)
{
  var cardno = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
    var n = cardno;
  if(inputtxt.value.match(cardno))
        {
         alert("You have done Payment Successfully.");
            return true;
        }
      else
        {
        alert("Not a valid Visa Credit Card Number!");
        return false;
        }
}

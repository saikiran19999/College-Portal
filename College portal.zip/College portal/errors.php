<?php if(count($errors) > 0 ) : ?>

<div>

    <?php foreach($errrors as $error) : ?>

            <P><?php echo $error ?></P>
    
        <?php endforeach ?>
    
</div>

<?php endif ?>
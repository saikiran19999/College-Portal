<? php include('connection.php') ?>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Egnigyan Education</title>
      <link rel="stylesheet" href="student.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
      <script src="http://code.jquery.com/jquery-3.3.1.js"></script>
      <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600" rel="stylesheet">
</head>
<body>

    <div id ="container">
       
        <div id="topbar">
            <h1>EGNIGYAN</h1>
             <img src="images/logo.jpg" height="50" width="50">
                
        </div>
          </div>
    
      <nav>
        
            <div>
                  <i class="fa fa-bars"></i>
               
            </div>
     
            <ul>
                  <li><a href="Acollege%20portal.html">Admin</a></li>
                  <li><a href="#">Student portal<i class="fa fa-sort-desc"></i></a>
                        <ul>
                              <li><a href="student_login.php">Student Login</a></li>
                              <li><a href="payments.html">Payments</a></li>
                             
                        </ul>
                  </li>
                  <li><a href="#">Faculty portal<i class="fa fa-sort-desc"></i></a>
                        <ul>
                              <li><a href="faculty_login.html">Faculty Login</a></li>
                             
                        </ul>
                  </li>
                 <li><a href="registration.php">Courses Registration form</a></li>
                  <li><a href="parent.html">Parent Login</a></li>
                  <li><a href="5.html">About</a></li>
                  <li><a href="6.html">FAQ</a></li>
            </ul>
           
      </nav>
    
    <div class ="container2">
                <div class="imgbox1">
                    <img src="images/student.jpg" width="100" height="100" border="3" style="border-color: darkgoldenrod">
                </div>
            <h3><a href="student_login.html">Egnigyan Student Portal</a></h3>
                <p>You can Login here and check your dashboard and check your attendence and Course registration and Academic track and also 
        placements.</p>
                    
            </div>
    
    <form action="student_login.php" method="post">
                  <div class="box">
       <h2>Student Login</h2>
        <form name="login">
        <div class="inputbox">
            <input type="text" name="userid" required"">
            <label>Username</label>
            </div>
        <div class="inputbox">
            <input type="password" name="password" required"">
            <label>password</label>
            </div>
            <input type="button" name="" value="submit" onclick="check(this.form)" >
     
        </form>
    </div>
    
    
    <script language="javascript">
function check(form)
{
 
 if(form.userid.value == "myuserid" && form.password.value == "mypassword")
  {
    window.open('student_dashboard.html')
  }
 else
 {
   alert("Error Password or Username. Please type username and password as myuserid and mypassword")
  }
}
</script>
    </form>
     <div class ="container6">
                <div class="bottombar">
                    <h5>Our Social media</h5>  
                    <div class="bar">
               <a class="btn" href="https://m.facebook.com/engigyanlivetraining/">
                    <i class="fab fa-facebook-f"></i>
                    </a>
                   <a class="btn" href="https://www.engigyan.com">
                    <i class="fab fa-google"></i>
                    </a>
          <a class="btn" href="https://www.instagram.com/engigyan/?hl=en">
                    <i class="fab fa-instagram"></i>
                    </a>
                    </div>
                    <p class="para1">ENGIGYAN - ALL RIGHTS RESERVED.</p>
                    <p class="para2">Powered by Engigyan Technology Private Limited.</p>
         </div></div>
    
      <script type="text/javascript">

      $("nav div").click(function() {
            $("ul").slideToggle();
            $("ul ul").css("display", "none");
      });

      $("ul li").click(function() {
            $("ul ul").slideUp();
            $(this).find('ul').slideToggle();
      });

      $(window).resize(function() {
            if($(window).width() > 768) {
                  $("ul").removeAttr('style');
            }
      });

      </script>

</body>
</html>
